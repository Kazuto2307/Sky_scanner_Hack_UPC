import { StaticQuestion } from '../types';

export const STATIC_QUESTIONS: Omit<StaticQuestion, 'importance'>[] = [
  {
    id: 'art',
    question: 'How important is art and culture to you when traveling?'
  },
  {
    id: 'food',
    question: 'How important is trying local cuisine and food experiences?'
  },
  {
    id: 'nature',
    question: 'How important are natural landscapes and outdoor activities?'
  },
  {
    id: 'luxury',
    question: 'How important is luxury and comfort during your travels?'
  },
  {
    id: 'adventure',
    question: 'How important are adventurous or adrenaline-pumping activities?'
  }
];