import React from 'react';
import { useTravelContext } from '../context/TravelContext';
import Button from './Button';
import { MapPin, Sparkles, Plane } from 'lucide-react';

const Results: React.FC = () => {
  const { getCurrentSession, createNewSession } = useTravelContext();
  const currentSession = getCurrentSession();
  
  if (!currentSession) {
    return <div className="text-center p-6">No session found. Please start over.</div>;
  }

  // This would typically come from an API that processes all user inputs
  // For demo purposes, we're generating mock recommendations
  const mockDestinations = [
    {
      name: "Barcelona, Spain",
      description: "A perfect blend of beach, culture, and gastronomy with architectural wonders.",
      match: 98,
      imageUrl: "https://images.pexels.com/photos/1388030/pexels-photo-1388030.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    },
    {
      name: "Kyoto, Japan",
      description: "Traditional temples, gardens and cuisine with a modern touch.",
      match: 92,
      imageUrl: "https://images.pexels.com/photos/1440476/pexels-photo-1440476.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    },
    {
      name: "Cape Town, South Africa",
      description: "Stunning landscapes, diverse wildlife and vibrant city life.",
      match: 87,
      imageUrl: "https://images.pexels.com/photos/259447/pexels-photo-259447.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
    }
  ];
  
  const handleStartNewSession = () => {
    createNewSession();
  };
  
  return (
    <div className="w-full max-w-4xl mx-auto bg-white rounded-xl shadow-md overflow-hidden">
      <div className="p-8">
        <div className="flex items-center justify-center mb-6">
          <Sparkles className="text-blue-900 mr-2" size={24} />
          <h2 className="text-2xl font-bold text-blue-900">Your Perfect Destinations</h2>
        </div>
        
        <p className="text-gray-600 mb-8 text-center">
          Based on your preferences and ratings, we've found these destinations that match your travel style perfectly.
        </p>
        
        <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-1">
          {mockDestinations.map((destination, index) => (
            <div 
              key={index} 
              className="rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 bg-white border border-gray-100"
            >
              <div className="md:flex">
                <div className="md:w-1/3">
                  <img 
                    src={destination.imageUrl} 
                    alt={destination.name} 
                    className="w-full h-48 md:h-full object-cover"
                  />
                </div>
                <div className="p-6 md:w-2/3 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <div className="flex items-center">
                        <MapPin className="text-orange-500 mr-2" size={18} />
                        <h3 className="text-xl font-bold text-blue-900">{destination.name}</h3>
                      </div>
                      <div className="bg-blue-50 text-blue-900 px-3 py-1 rounded-full text-sm font-medium">
                        {destination.match}% Match
                      </div>
                    </div>
                    <p className="text-gray-600 mt-2">{destination.description}</p>
                  </div>
                  
                  <div className="mt-4">
                    <Button
                      variant="outline"
                      onClick={() => {}}
                      className="w-full justify-center"
                    >
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="flex justify-center mt-8">
          <Button
            onClick={handleStartNewSession}
            variant="primary"
            className="flex items-center"
          >
            <Plane className="mr-2" size={16} />
            Start New Adventure
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Results;