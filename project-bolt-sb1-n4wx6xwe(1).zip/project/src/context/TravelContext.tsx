import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Session, GeneratedQuestion, StaticQuestion, TierListData, GeographicalPreference } from '../types';
import { generateUniqueId } from '../utils';
import { STATIC_QUESTIONS } from '../constants';

interface TravelContextType {
  sessions: Session[];
  currentSessionId: string | null;
  createNewSession: () => void;
  switchSession: (sessionId: string) => void;
  updatePreferences: (sessionId: string, text: string) => void;
  updateGeneratedQuestions: (sessionId: string, questions: GeneratedQuestion[]) => void;
  updateStaticQuestionImportance: (sessionId: string, questionId: string, importance: number) => void;
  updateTierList: (sessionId: string, tierList: TierListData) => void;
  updateGeographicalPreferences: (sessionId: string, preferences: GeographicalPreference) => void;
  moveToNextStep: (sessionId: string) => void;
  getCurrentSession: () => Session | null;
}

const TravelContext = createContext<TravelContextType | undefined>(undefined);

export const TravelProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);

  const createNewSession = () => {
    const newSessionId = generateUniqueId();

    const initialStaticQuestions = STATIC_QUESTIONS.map(question => ({
      ...question,
      importance: 0,
    }));

    const initialTierList: TierListData = {
      S: [],
      A: [],
      B: [],
      C: [],
      unranked: ['food', 'culture', 'nightlife', 'beach', 'mountain', 'outdoor', 'city', 'original'],
    };

    const newSession: Session = {
      id: newSessionId,
      preferences: null,
      generatedQuestions: [],
      staticQuestions: initialStaticQuestions,
      currentStep: 'tierList',
      tierList: initialTierList,
      geographical: {
        homeCity: '',
        selectedContinent: null
      }
    };

    setSessions(prevSessions => [...prevSessions, newSession]);
    setCurrentSessionId(newSessionId);
    
    return newSessionId;
  };

  const switchSession = (sessionId: string) => {
    setCurrentSessionId(sessionId);
  };

  const updatePreferences = (sessionId: string, text: string) => {
    setSessions(prevSessions =>
      prevSessions.map(session =>
        session.id === sessionId
          ? {
              ...session,
              preferences: { id: generateUniqueId(), text },
            }
          : session
      )
    );
  };

  const updateGeneratedQuestions = (sessionId: string, questions: GeneratedQuestion[]) => {
    setSessions(prevSessions =>
      prevSessions.map(session =>
        session.id === sessionId
          ? {
              ...session,
              generatedQuestions: questions,
            }
          : session
      )
    );
  };

  const updateStaticQuestionImportance = (sessionId: string, questionId: string, importance: number) => {
    setSessions(prevSessions =>
      prevSessions.map(session =>
        session.id === sessionId
          ? {
              ...session,
              staticQuestions: session.staticQuestions.map(q =>
                q.id === questionId ? { ...q, importance } : q
              ),
            }
          : session
      )
    );
  };

  const updateTierList = (sessionId: string, tierList: TierListData) => {
    setSessions(prevSessions =>
      prevSessions.map(session =>
        session.id === sessionId
          ? {
              ...session,
              tierList,
            }
          : session
      )
    );
  };

  const updateGeographicalPreferences = (sessionId: string, preferences: GeographicalPreference) => {
    setSessions(prevSessions =>
      prevSessions.map(session =>
        session.id === sessionId
          ? {
              ...session,
              geographical: preferences,
            }
          : session
      )
    );
  };

  const moveToNextStep = (sessionId: string) => {
    setSessions(prevSessions =>
      prevSessions.map(session => {
        if (session.id !== sessionId) return session;

        const steps = ['tierList', 'preferences', 'geographical', 'generatedQuestions', 'staticQuestions', 'results'] as const;
        const currentStepIndex = steps.indexOf(session.currentStep);
        
        if (currentStepIndex < steps.length - 1) {
          return {
            ...session,
            currentStep: steps[currentStepIndex + 1],
          };
        }
        
        return session;
      })
    );
  };

  const getCurrentSession = (): Session | null => {
    if (!currentSessionId) return null;
    return sessions.find(session => session.id === currentSessionId) || null;
  };

  const value = {
    sessions,
    currentSessionId,
    createNewSession,
    switchSession,
    updatePreferences,
    updateGeneratedQuestions,
    updateStaticQuestionImportance,
    updateTierList,
    updateGeographicalPreferences,
    moveToNextStep,
    getCurrentSession,
  };

  return <TravelContext.Provider value={value}>{children}</TravelContext.Provider>;
};

export const useTravelContext = () => {
  const context = useContext(TravelContext);
  
  if (context === undefined) {
    throw new Error('useTravelContext must be used within a TravelProvider');
  }
  
  return context;
};