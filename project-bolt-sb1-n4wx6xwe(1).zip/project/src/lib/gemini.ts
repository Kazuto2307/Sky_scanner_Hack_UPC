import { GoogleGenerativeAI } from '@google/generative-ai';
import { Preferences, Recipe, MealPlan, ShoppingItem } from '../types';

const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
if (!apiKey) {
  throw new Error('Gemini API key not configured');
}

const genAI = new GoogleGenerativeAI(apiKey);
const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

export async function ObtainCities(tier_list: string[], free_text: string[], continents: string[]): Promise<Recipe[]> {
  const prompt = `A group of people wants to make a travel, where the most important aspects are: ${tier_list.join(', ')}. They preferences are ${free_text} and the most liked continents to visit are ${continents}. Think of the 10 ccities that are most suitable for this travel. For each city give also a mark for how good may it be. Return me this list in a json of the following form:{'Barcelona': 10, 'Milan': 9, ...} '`;

  try {
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('Invalid response format');
    }
    

    const parsed = JSON.parse(`[${cleanedJsonString}]`);
    
   
    return parsed;
    
  } catch (error) {
    console.error('Error suggesting cities:', error);
    return [];
  }
}