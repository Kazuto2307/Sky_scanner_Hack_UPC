import { Continent } from '../constants';

export interface TravelPreference {
  id: string;
  text: string;
}

export interface GeneratedQuestion {
  id: string;
  question: string;
  answer: string;
}

export interface StaticQuestion {
  id: string;
  question: string;
  importance: number;
}

export interface GeographicalPreference {
  homeCity: string;
  selectedContinent: Continent | null;
}

export interface Session {
  id: string;
  preferences: TravelPreference | null;
  generatedQuestions: GeneratedQuestion[];
  staticQuestions: StaticQuestion[];
  currentStep: 'tierList' | 'preferences' | 'geographical' | 'generatedQuestions' | 'staticQuestions' | 'results';
  tierList: TierListData;
  geographical: GeographicalPreference;
}

export interface TravelAspect {
  id: string;
  name: string;
  icon: string;
}

export interface TierListData {
  S: string[];
  A: string[];
  B: string[];
  C: string[];
  unranked: string[];
}

export type TierType = 'S' | 'A' | 'B' | 'C' | 'unranked';